import React, { useRef, useState } from 'react';

import { Container, Row, Col, Modal } from 'react-bootstrap';
import Link from 'next/link';

export default function TestPage() {
  const [showModal01, setShowModal01] = useState(false);
  const [showModal02, setShowModal02] = useState(false);

  const handleCloseModal01 = () => setShowModal01(false);
  const handleShowModal01 = () => setShowModal01(true);

  const handleCloseModal02 = () => setShowModal02(false);
  const handleShowModal02 = () => setShowModal02(true);
  return (
    <div>
      <Modal className="" show={showModal01} onHide={handleCloseModal01}>
        <Modal.Header>
          <button className="btn-modal-close" onClick={handleCloseModal01}>
            <i className="bi bi-x-lg"></i>
          </button>
        </Modal.Header>
        <Modal.Body>
          First modal
          <Link href="" className="programme-item" onClick={handleShowModal02}>
            222
          </Link>
        </Modal.Body>
      </Modal>

      <Modal className="" show={showModal02} onHide={handleCloseModal02}>
        <Modal.Header>
          <button className="btn-modal-close" onClick={handleCloseModal02}>
            <i className="bi bi-x-lg"></i>
          </button>
        </Modal.Header>
        <Modal.Body>Secon modal</Modal.Body>
      </Modal>

      <Link href="" className="programme-item" onClick={handleShowModal01}>
        111
      </Link>
    </div>
  );
}
